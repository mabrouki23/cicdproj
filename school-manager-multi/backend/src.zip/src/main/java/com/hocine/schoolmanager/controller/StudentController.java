package com.hocine.schoolmanager.controller;

import com.hocine.schoolmanager.model.Student;
import com.hocine.schoolmanager.repository.StudentRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "*")
public class StudentController {{
  private final StudentRepository repo;
  public StudentController(StudentRepository repo) {{ this.repo = repo; }}
  @GetMapping public List<Student> all() {{ return repo.findAll(); }}
  @PostMapping public Student create(@RequestBody Student e) {{ return repo.save(e); }}
  @DeleteMapping("/{id}") public void delete(@PathVariable Long id) {{ repo.deleteById(id); }}
}}
