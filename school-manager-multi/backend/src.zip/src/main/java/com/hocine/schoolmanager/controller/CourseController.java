package com.hocine.schoolmanager.controller;

import com.hocine.schoolmanager.model.Course;
import com.hocine.schoolmanager.repository.CourseRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/courses")
@CrossOrigin(origins = "*")
public class CourseController {{
  private final CourseRepository repo;
  public CourseController(CourseRepository repo) {{ this.repo = repo; }}
  @GetMapping public List<Course> all() {{ return repo.findAll(); }}
  @PostMapping public Course create(@RequestBody Course e) {{ return repo.save(e); }}
  @DeleteMapping("/{id}") public void delete(@PathVariable Long id) {{ repo.deleteById(id); }}
}}
