package com.hocine.schoolmanager.controller;

import com.hocine.schoolmanager.model.Room;
import com.hocine.schoolmanager.repository.RoomRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin(origins = "*")
public class RoomController {{
  private final RoomRepository repo;
  public RoomController(RoomRepository repo) {{ this.repo = repo; }}
  @GetMapping public List<Room> all() {{ return repo.findAll(); }}
  @PostMapping public Room create(@RequestBody Room e) {{ return repo.save(e); }}
  @DeleteMapping("/{id}") public void delete(@PathVariable Long id) {{ repo.deleteById(id); }}
}}
