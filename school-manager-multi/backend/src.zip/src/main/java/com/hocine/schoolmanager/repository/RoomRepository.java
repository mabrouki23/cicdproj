package com.hocine.schoolmanager.repository;

import com.hocine.schoolmanager.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository extends JpaRepository<Room, Long> {}
