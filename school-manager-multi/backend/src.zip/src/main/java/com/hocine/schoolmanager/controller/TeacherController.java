package com.hocine.schoolmanager.controller;

import com.hocine.schoolmanager.model.Teacher;
import com.hocine.schoolmanager.repository.TeacherRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/teachers")
@CrossOrigin(origins = "*")
public class TeacherController {{
  private final TeacherRepository repo;
  public TeacherController(TeacherRepository repo) {{ this.repo = repo; }}
  @GetMapping public List<Teacher> all() {{ return repo.findAll(); }}
  @PostMapping public Teacher create(@RequestBody Teacher e) {{ return repo.save(e); }}
  @DeleteMapping("/{id}") public void delete(@PathVariable Long id) {{ repo.deleteById(id); }}
}}
